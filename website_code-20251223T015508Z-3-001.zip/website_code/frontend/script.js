const API = "http://136.118.169.96:8000";

/* Show sections */
function showSection(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

/* SIGNUP */
async function signup() {
  const username = document.getElementById("signup-username").value;
  const password = document.getElementById("signup-password").value;

  const res = await fetch(`${API}/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });

  if (res.ok) alert("Signup successful!");
  else alert("Signup failed!");
}

/* LOGIN */
async function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  const res = await fetch(`${API}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });

  const data = await res.json();

  if (res.ok) {
    localStorage.setItem("token", data.access_token);
    document.getElementById("classify-tab").classList.remove("hidden");
    alert("Login successful!");
    showSection("classify");
  } else {
    alert("Invalid credentials!");
  }
}

/* CLASSIFY */
async function uploadImage() {
  const file = document.getElementById("imageInput").files[0];
  if (!file) return alert("Select an image");

  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${API}/classify`, {
    method: "POST",
    headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    body: formData
  });

  const data = await res.json();

  const labels = ["No Cancer", "Low Severity", "High Severity"];

  document.getElementById("result").innerHTML =
    `<p>Prediction: <b>${labels[data.a]}</b><br>Confidence: ${data.b.toFixed(2)}%</p>`;
}
